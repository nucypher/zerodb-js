
PyPy.js:  PyPy compiled into JavaScript
=======================================

PyPy.  Compiled into JavaScript.  JIT-compiling to JavaScript at runtime.
Because why not.

This will be a description of how to use the built distribution.  It's
different from the repo-level README which describes how to hack on the
build itself.
